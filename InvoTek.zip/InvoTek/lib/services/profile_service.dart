import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

import '../model/common/profile.dart';

class ProfileService {
  final FirebaseFirestore _firebaseFirestore;

  ProfileService(
    FirebaseFirestore? firebaseFirestore,
  ) : _firebaseFirestore = firebaseFirestore ??= FirebaseFirestore.instance;

  Future<Profile?> getProfileData(String uid) async {
    final doc = await _firebaseFirestore.collection('profiles').doc(uid).get();
    if (doc.exists) {
      return Profile.fromJson(doc.data()!);
    } else {
      debugPrint('Doc profile does\'nt exist!');
      return null;
    }
  }

  Future<DocumentSnapshot> getProfile(String uid) async {
    return await FirebaseFirestore.instance.collection('users').doc(uid).get();
  }

  Future<void> saveProfileData(String uid, Profile profile) async {
    final docRef = _firebaseFirestore.collection('profiles').doc(uid);
    final docSnapshot = await docRef.get();

    if (docSnapshot.exists) {
      await docRef.update(profile.toJson());
    } else {
      await docRef.set(profile.toJson());
    }
  }
}
